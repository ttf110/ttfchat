import React, { useState } from 'react'

function Message({ m }) {
  return (
    <div className={m.role === 'user' ? 'msg user' : 'msg bot'}>
      <div className="bubble">{m.content}</div>
    </div>
  )
}

export default function App() {
  const [text, setText] = useState('')
  const [messages, setMessages] = useState([
    { role: 'bot', content: 'Welcome to TTFCHAT — ask me anything.' }
  ])
  const [loading, setLoading] = useState(false)

  async function send() {
    if (!text.trim()) return
    const userMsg = { role: 'user', content: text.trim() }
    setMessages(prev => [...prev, userMsg])
    setText('')
    setLoading(true)
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMsg.content })
      })
      if (!res.ok) throw new Error('Network error')
      const data = await res.json()
      const reply = data?.reply ?? 'No response'
      setMessages(prev => [...prev, { role: 'bot', content: reply }])
    } catch (err) {
      setMessages(prev => [...prev, { role: 'bot', content: 'Error: ' + err.message }])
    } finally {
      setLoading(false)
    }
  }

  function onKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      send()
    }
  }

  return (
    <div className="app">
      <header className="header">
        <div className="logo">TTFCHAT</div>
        <div className="sub">White Modern AI Chat</div>
      </header>

      <main className="chat">
        <div className="messages">
          {messages.map((m, i) => <Message key={i} m={m} />)}
        </div>
        <div className="composer">
          <textarea
            placeholder="Type your message and press Enter..."
            value={text}
            onChange={e => setText(e.target.value)}
            onKeyDown={onKey}
          />
          <button onClick={send} disabled={loading}>{loading ? 'Sending...' : 'Send'}</button>
        </div>
      </main>

      <footer className="footer">© {new Date().getFullYear()} TTFCHAT</footer>
    </div>
  )
}
